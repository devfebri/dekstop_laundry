package com.laundry.gui;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;

public class LaundryDemo extends JFrame{
    private JPanel panelMain;
    private JTextField textFieldNama;
    private JTextField textFieldBerat;
    private JTextField textFieldNoHp;
    private JButton insertFirstButton;
    private JButton insertLastButton;
    private JList jListConsumen;
    private JButton clearButton;
    private DefaultListModel defaultListModel=new DefaultListModel();
    private List<String> arrayListConsumen = new ArrayList<>();
    private LingkedList<Consumen> ListConsumen = new LingkedList<>();




    class Consumen{
        private String nama;
        private String nohp;
        private String berat;

        public String getNama() {
            return nama;
        }

        public void setNama(String nama) {
            this.nama = nama;
        }

        public String getNohp() {
            return nohp;
        }

        public void setNohp(String nohp) {
            this.nohp = nohp;
        }

        public String getBerat() {
            return berat;
        }

        public void setBerat(String berat) {
            this.berat = berat;
        }

    }

    public LaundryDemo(){
        this.setContentPane(panelMain);
        this.setDefaultCloseOperation(EXIT_ON_CLOSE);
        this.pack();
        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearForm();
            }
        });
        insertFirstButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nama = textFieldNama.getText();
                String nohp=textFieldNoHp.getText();
                String berat= textFieldBerat.getText();

                Consumen consumen  = new Consumen();
                consumen.setNama(nama);
                consumen.setNohp(nohp);
                consumen.setBerat(berat);

                insertFirst(consumen);
                clearForm();
                refreshDataModel();

            }
        });
        insertLastButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nama = textFieldNama.getText();
                String nohp=textFieldNoHp.getText();
                String berat= textFieldBerat.getText();

                Consumen consumen  = new Consumen();
                consumen.setNama(nama);
                consumen.setNohp(nohp);
                consumen.setBerat(berat);

                insertLast(consumen);
                clearForm();
                refreshDataModel();
            }
        });
        jListConsumen.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int index=jListConsumen.getSelectedIndex();

                Consumen hasilSearch = search(arrayListConsumen.get(index));

                if(hasilSearch != null){
                    textFieldNoHp.setText(hasilSearch.getNohp());
                    textFieldNama.setText(hasilSearch.getNama());
                    textFieldBerat.setText(hasilSearch.getBerat());

                }

            }
        });
    }
    private Consumen search(String nama){
        for (Consumen consumen : ListConsumen){
            if(consumen==null)
                break;

            if(consumen.getNama().equals(nama))
                return consumen;
        }
        return null;
    }


    private void refreshDataModel(){
        arrayListConsumen.clear();

        for (Consumen consumen : ListConsumen){
            if(consumen==null)
                break;

            arrayListConsumen.add(consumen.getNama());
        }

        defaultListModel.clear();
        defaultListModel.addAll(arrayListConsumen);
        jListConsumen.setModel(defaultListModel);
    }
    private void insertFirst(Consumen consumen){
        ListConsumen.insertFirst(consumen);
    }
    private void insertLast(Consumen consumen){
        ListConsumen.insertLast(consumen);
    }
    private void clearForm(){
        textFieldBerat.setText("");
        textFieldNama.setText("");
        textFieldNoHp.setText("");
    }

    public static void main(String [] args){
        LaundryDemo laundryDemo=new LaundryDemo();
        laundryDemo.setVisible(true);
    }
}
